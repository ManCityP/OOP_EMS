package p2;

public enum Status {
    UPCOMING, ONGOING, OVER
}
